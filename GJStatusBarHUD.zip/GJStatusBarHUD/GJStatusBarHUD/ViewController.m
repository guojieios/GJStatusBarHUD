//
//  ViewController.m
//  GJStatusBarHUD
//
//  Created by apple on 16/7/2.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "ViewController.h"
#import "GJStatusBarHUD.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




#pragma mark - 显示普通信息
- (IBAction)normalMessage:(id)sender {
    
    [GJStatusBarHUD GJ_ShowNormalMessage:@"显示自定义信息"];
    
}


#pragma mark - 隐藏
- (IBAction)hide:(id)sender {
    
    [GJStatusBarHUD GJ_hide];
    
}


#pragma mark - 正在加载
- (IBAction)loading:(id)sender {
    
    [GJStatusBarHUD GJ_ShowLoading:@"正在加载中..."];
    
}


#pragma mark - 失败信息
- (IBAction)error:(id)sender {
    
    [GJStatusBarHUD GJ_ShowError:@"加载失败!"];
    
}


#pragma mark - 成功信息
- (IBAction)success:(id)sender {
    
    [GJStatusBarHUD GJ_ShowSuccess:@"加载成功!"];
    
}















@end
