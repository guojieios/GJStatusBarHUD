//
//  GJStatusBarHUD.h
//  GJStatusBarHUD
//
//  Created by apple on 16/7/2.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GJStatusBarHUD : NSObject

/* 
 * 显示成功信息
 * @param message    内容
 * @param image      图片
 *
 */
+ (void)GJ_ShowSuccess:(NSString *)message image:(UIImage *)image;


// 显示成功信息
+ (void)GJ_ShowSuccess:(NSString *)message;


// 显示失败信息
+ (void)GJ_ShowError:(NSString *)message;



// 显示正在处理信息
+ (void)GJ_ShowLoading:(NSString *)message;



// 隐藏
+ (void)GJ_hide;

// 显示信息
+ (void)GJ_ShowNormalMessage:(NSString *)message;

@end
