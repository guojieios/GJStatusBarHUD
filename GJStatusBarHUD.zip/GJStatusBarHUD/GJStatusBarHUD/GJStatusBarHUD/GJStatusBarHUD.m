//
//  GJStatusBarHUD.m
//  GJStatusBarHUD
//
//  Created by apple on 16/7/2.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "GJStatusBarHUD.h"

#define GJMessageFont [UIFont systemFontOfSize:12.0]

/** 消息的停留时间 */
static CGFloat const GJMessageDuration = 2.0;
/** 消息显示\隐藏的动画时间 */
static CGFloat const GJAnimationDuration = 0.25;

@implementation GJStatusBarHUD

static UIWindow *window_;

// 定时器
static NSTimer *timer_;


#pragma mark - 初始化窗口
+ (void)setupWindow {
    
    // 动画
    // frame 数据
    CGFloat windowH = 20;
    CGRect frame = CGRectMake(0, -windowH, [UIScreen mainScreen].bounds.size.width, windowH);
    
    
    // 显示窗口
//    window_.hidden = YES;
    window_ = [[UIWindow alloc] init];
    window_.backgroundColor = [UIColor blackColor];
    // 设置窗口的级别最高
    window_.windowLevel = UIWindowLevelAlert;
    
    window_.frame = CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, windowH);
    
    window_.hidden = NO;
    
    
    
    // 显示动画
    
    frame.origin.y = 0;
    
    [UIView animateWithDuration:GJMessageDuration animations:^{
        
        
        window_.frame = frame;
        
    }];
    
}


/*
 * 显示成功信息
 * @param message    内容
 * @param image      图片
 *
 */
+ (void)GJ_ShowSuccess:(NSString *)message image:(UIImage *)image {
    
    
    // 停止定时器
    [timer_ invalidate];
    
    [self setupWindow];
    
    
    // 添加按钮
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    
    
    if (image) {
        
        [button setImage:image forState:UIControlStateNormal];

        
        button.titleEdgeInsets = UIEdgeInsetsMake(0, 10, 0, 0);
        
        
        
    }
    
    [button setTitle:message forState:UIControlStateNormal];
    
    button.titleLabel.font = GJMessageFont;
    
    
    button.frame = window_.bounds;
    
    [window_ addSubview:button];
    
    
    
    // 定时消失
    timer_ = [NSTimer scheduledTimerWithTimeInterval:GJMessageDuration target:self selector:@selector(GJ_hide) userInfo:nil repeats:NO];
    
    
    
    
    
}


// 显示成功信息
+ (void)GJ_ShowSuccess:(NSString *)message {
    
    [self GJ_ShowSuccess:message image:[UIImage imageNamed:@"GJStatusBarHUD.bundle/success"]];
    
}


// 显示失败信息
+ (void)GJ_ShowError:(NSString *)message {
    
    [self GJ_ShowSuccess:message image:[UIImage imageNamed:@"GJStatusBarHUD.bundle/error"]];
    
}



// 显示正在处理信息
+ (void)GJ_ShowLoading:(NSString *)message {
    
    // 停止定时器
    [timer_ invalidate];
    timer_ = nil;
    
    
    // 显示窗口
    [self setupWindow];
    
    
    // 添加文字
    UILabel *label = [[UILabel alloc] init];
    
    label.font = GJMessageFont;
    label.frame = window_.bounds;
    label.textAlignment = NSTextAlignmentCenter;
    label.text = message;
    label.textColor = [UIColor whiteColor];
    
    
    [window_ addSubview:label];
    
    
    // 添加圈圈
    UIActivityIndicatorView *loadView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite];
    
    [loadView startAnimating];
    
    CGFloat messageW = [message sizeWithAttributes:@{NSFontAttributeName : GJMessageFont}].width;
    CGFloat centerX = (window_.frame.size.width - messageW) * 0.5 - 20;
    CGFloat centerY = window_.frame.size.height * 0.5;
    
    
    loadView.center = CGPointMake(centerX, centerY);
    
    [window_ addSubview:loadView];
    
    
    
}



// 隐藏
+ (void)GJ_hide {
   
    
    [UIView animateWithDuration:GJAnimationDuration animations:^{
        
        CGRect frame = window_.frame;
        
        frame.origin.y = - frame.size.height;
        
        window_.frame = frame;
        
        
    } completion:^(BOOL finished) {
        
        
        window_ = nil;
    
        timer_ = nil;
        
    }];
    
    
    
    
}


// 显示信息
+ (void)GJ_ShowNormalMessage:(NSString *)message {
    
    [self GJ_ShowSuccess:message image:nil];
}





@end
